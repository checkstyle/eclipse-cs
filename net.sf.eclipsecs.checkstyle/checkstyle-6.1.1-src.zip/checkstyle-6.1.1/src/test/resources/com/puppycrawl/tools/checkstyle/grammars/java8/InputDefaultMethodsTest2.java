package com.puppycrawl.tools.checkstyle.grammars.java8;

public class InputDefaultMethodsTest2 {
	
	public void doSomething(){
		int a = 5;
        switch (a)
        {
        case 0:
            break;
        
        default:
            break;
        
        }

	}

}
