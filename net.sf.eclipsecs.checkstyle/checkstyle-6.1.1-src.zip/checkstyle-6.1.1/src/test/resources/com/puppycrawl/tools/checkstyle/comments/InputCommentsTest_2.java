// my class
class A
{
    /**
     * Lines <b>method</b>.
     * 
     * @return string.
     */
    protected String line()
    {
    }
}
