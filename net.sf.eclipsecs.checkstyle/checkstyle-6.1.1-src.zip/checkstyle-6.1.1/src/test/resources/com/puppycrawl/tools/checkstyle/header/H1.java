/*
 * (C) 2006 correct header
 */

package com.puppycrawl.tools.checkstyle.header;

public class H1
{
}
