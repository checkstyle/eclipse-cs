class Foo{

	/** As of JDK 1.1, replaced by {@link #setBounds(int,int,int,int)} */
    void foo1() {}

    /**
     * As of JDK 1.1, replaced by {@link #setBounds(int,int,int,int)}
     */
    void foo1() {}

    /** @throws CheckstyleException if an error occurs */
    void foo1() {}

    /**
     * @throws CheckstyleException if an error occurs
     */
    void foo1() {}

    /** An especially short bit of Javadoc. */
    void foo1() {}

    /**
     * An especially short bit of Javadoc.
     */
    void foo1() {}
}