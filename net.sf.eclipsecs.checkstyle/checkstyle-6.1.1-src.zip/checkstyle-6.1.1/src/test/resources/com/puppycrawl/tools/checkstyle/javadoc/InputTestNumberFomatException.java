/** <ul><li>a' {@link EntityEntry} (by way of {@link #;}</li></ul> */
class InputTestNumberFomatException{}