package com.puppycrawl.tools.checkstyle.checks.design.designforextension;

public class InputDesignForExtensionsLocalAnnotations
{
    public @interface Rule {
        
    }

    public @interface ClassRule {

    }
}
