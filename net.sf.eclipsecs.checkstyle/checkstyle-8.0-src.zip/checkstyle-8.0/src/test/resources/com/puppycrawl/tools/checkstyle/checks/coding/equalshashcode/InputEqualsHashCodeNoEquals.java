package com.puppycrawl.tools.checkstyle.checks.coding.equalshashcode;

public class InputEqualsHashCodeNoEquals {
    public int hashCode() {
        return 1;
    }
}
