 package com.puppycrawl.tools.checkstyle.checks.indentation.indentation;//indent:1 exp:0 warn

public class InputIndentationPackageDeclaration {}//indent:0 exp:0
