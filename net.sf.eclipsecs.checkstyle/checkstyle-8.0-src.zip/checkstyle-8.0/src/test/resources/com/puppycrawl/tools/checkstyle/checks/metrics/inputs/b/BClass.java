package com.puppycrawl.tools.checkstyle.checks.metrics.inputs.b;

public class BClass {
}
