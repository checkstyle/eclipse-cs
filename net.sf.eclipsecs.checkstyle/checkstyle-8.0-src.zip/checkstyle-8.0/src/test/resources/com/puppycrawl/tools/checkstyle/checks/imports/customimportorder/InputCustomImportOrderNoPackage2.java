

import static com.puppycrawl.tools.checkstyle.utils.AnnotationUtility.containsAnnotation;
import static com.puppycrawl.tools.checkstyle.utils.AnnotationUtility.getAnnotation;


import com.sun.accessibility.internal.resources.*;



import java.util.Arrays;
import java.util.BitSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import javax.accessibility.Accessible;


import org.apache.commons.beanutils.converters.ArrayConverter;

class InputCustomImportOrderNoPackage2 {

}
