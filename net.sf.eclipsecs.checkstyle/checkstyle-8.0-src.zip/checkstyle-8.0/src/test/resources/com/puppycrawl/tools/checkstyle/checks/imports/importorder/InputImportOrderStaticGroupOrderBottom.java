package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import org.*;

import java.util.Set;

import static java.lang.Math.PI;
import static org.antlr.v4.runtime.Recognizer.EOF;

public class InputImportOrderStaticGroupOrderBottom
{

}
