package com.puppycrawl.tools.checkstyle.grammars.comments;
public class /*
    i'mcomment567
    */
InputComments1
{ // comment to left curly brace
}
