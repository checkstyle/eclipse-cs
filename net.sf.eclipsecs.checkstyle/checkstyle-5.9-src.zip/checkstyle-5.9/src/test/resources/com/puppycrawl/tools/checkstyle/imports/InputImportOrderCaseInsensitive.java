package com.puppycrawl.tools.checkstyle.imports;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.io.Reader;
import static java.io.InputStream.*;
import static java.io.IOException.*;

public class InputImportOrderCaseInsensitive {
}
