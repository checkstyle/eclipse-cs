package com.puppycrawl.tools.checkstyle.javadoc.pkghtml;

class Ignored
{
}
