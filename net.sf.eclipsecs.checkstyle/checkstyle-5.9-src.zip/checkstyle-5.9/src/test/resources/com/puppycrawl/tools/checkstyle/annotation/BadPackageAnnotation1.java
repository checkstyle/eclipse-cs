@GunNRoses //this will not compile in Sun's compiler as of 1.6.0.11
package com.puppycrawl.tools.checkstyle.annotation;


public class BadPackageAnnotation1
{

}

@interface GunNRoses {
    
}
