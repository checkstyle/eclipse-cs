package com.google.common.cache;

import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

public class InputImportOrder {
}
