package com.puppycrawl.tools.checkstyle.grammars;

import java.util.Arrays;
;
import java.util.ArrayList;

public class SemicolonBetweenImports
{
}
