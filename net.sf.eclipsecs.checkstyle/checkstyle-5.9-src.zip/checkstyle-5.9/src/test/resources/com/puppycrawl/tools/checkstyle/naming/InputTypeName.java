package com.puppycrawl.tools.checkstyle.naming;

class inputHeaderClass {

    public interface inputHeaderInterface {};

    public enum inputHeaderEnum { one, two };

    public @interface inputHeaderAnnotation {};

}
