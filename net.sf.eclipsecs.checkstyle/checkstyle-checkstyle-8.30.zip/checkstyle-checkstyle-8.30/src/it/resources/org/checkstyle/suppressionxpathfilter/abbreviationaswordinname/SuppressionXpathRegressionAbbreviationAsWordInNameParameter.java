package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public interface SuppressionXpathRegressionAbbreviationAsWordInNameParameter {

    void method(int PARAMETER); // warn

}
