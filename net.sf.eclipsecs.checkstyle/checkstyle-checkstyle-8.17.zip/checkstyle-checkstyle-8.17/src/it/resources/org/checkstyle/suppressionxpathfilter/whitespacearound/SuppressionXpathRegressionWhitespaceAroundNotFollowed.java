package org.checkstyle.suppressionxpathfilter.whitespaceafter;

public class SuppressionXpathRegressionWhitespaceAroundNotFollowed {
    int bad =0; //warn
    int good = 0;
}
