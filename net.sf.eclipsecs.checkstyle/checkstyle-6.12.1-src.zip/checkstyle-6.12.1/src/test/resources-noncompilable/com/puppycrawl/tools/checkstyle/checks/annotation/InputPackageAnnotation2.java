@Deprecated
package com.puppycrawl.tools.checkstyle.checks.annotation;

public class InputPackageAnnotation2 {
	
}
