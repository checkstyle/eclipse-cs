package com.puppycrawl.tools.checkstyle.checks.javadoc;

/**
 * The following is a bad tag.
 * @mytag Hello
 */
public class InputBadTag
{
}
