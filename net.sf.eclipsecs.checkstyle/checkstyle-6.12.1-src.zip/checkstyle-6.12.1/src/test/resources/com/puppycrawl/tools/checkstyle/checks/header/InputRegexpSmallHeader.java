package com.puppycrawl.tools.checkstyle.checks.header;


/**
 */
public class InputRegexpSmallHeader {}
