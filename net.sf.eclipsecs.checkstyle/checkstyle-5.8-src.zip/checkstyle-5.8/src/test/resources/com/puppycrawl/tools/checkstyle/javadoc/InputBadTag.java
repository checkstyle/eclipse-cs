package com.puppycrawl.tools.checkstyle.javadoc;

/**
 * The following is a bad tag.
 * @mytag Hello
 */
public class InputBadTag
{
}
