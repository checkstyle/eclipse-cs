package com.puppycrawl.tools.checkstyle.imports;

import java.awt.Button;
import java.awt.Button;

public class InputImportOrder_NoFailureForRedundantImports {
}

