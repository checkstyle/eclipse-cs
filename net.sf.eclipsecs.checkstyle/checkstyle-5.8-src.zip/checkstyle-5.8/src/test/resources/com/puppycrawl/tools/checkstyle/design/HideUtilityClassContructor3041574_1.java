package com.puppycrawl.tools.checkstyle.design;

import java.io.Serializable;

public abstract class HideUtilityClassContructor3041574_1 implements Serializable {
    private static final long serialVersionUID = 1L;

}