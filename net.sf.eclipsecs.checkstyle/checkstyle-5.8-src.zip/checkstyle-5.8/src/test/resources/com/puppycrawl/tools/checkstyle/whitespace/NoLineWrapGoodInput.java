package com.puppycrawl.tools.checkstyle;

import com.google.common.annotations.Beta;

import javax.accessibility.AccessibleAttributeSequence;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public class GoodLineWrapInput {
    
	public void fooMethod() {
		//
	}
}
