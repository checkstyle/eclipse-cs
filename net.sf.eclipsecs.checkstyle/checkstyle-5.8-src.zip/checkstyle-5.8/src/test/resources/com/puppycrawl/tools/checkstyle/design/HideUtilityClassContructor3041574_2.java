package com.puppycrawl.tools.checkstyle.design;

import java.io.Serializable;

public class HideUtilityClassContructor3041574_2 implements Serializable {
    private static final long serialVersionUID = 1L;

}