import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;

public class B
{
    public static final int Y = 1;
    public static final int X = 0;
    public static final int Z = 2;
}
