// A class that is shorter than the number of lines considered a duplicate

public class Shorty {
}