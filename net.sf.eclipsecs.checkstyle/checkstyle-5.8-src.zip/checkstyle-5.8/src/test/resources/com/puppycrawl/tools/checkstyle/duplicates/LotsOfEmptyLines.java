// A class that contains lots of empty lines
// such files frequently occur in the JDK source code, most notably the machine generated nio Buffer variants

public class LotsOfEmptyLines {
// 15 empty lines
    














}
// 15 empty lines below














