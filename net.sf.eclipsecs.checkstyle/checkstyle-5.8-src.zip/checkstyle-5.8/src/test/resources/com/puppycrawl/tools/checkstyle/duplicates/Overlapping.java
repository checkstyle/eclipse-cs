// A class that has overlapping areas of duplication (min=3)

public class Overlapping {

    public void m1() {
        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;
    }

    public void m2() {
        int a = 0;
        int b = 0;
        int c = 0;
    }

    public void m3() {
        int b = 0;
        int c = 0;
        int d = 0;
    }

    public void m4() {
        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;
    }
}