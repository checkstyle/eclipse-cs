Example of an ant build file and stylesheet for generation of an HTML error
report with links to source code, as discussed on sourceforge.net:
checkstyle-user,
http://sourceforge.net/mailarchive/forum.php?thread_id=4891991&forum_id=8139.

Requires: java2html, http://www.java2html.de/