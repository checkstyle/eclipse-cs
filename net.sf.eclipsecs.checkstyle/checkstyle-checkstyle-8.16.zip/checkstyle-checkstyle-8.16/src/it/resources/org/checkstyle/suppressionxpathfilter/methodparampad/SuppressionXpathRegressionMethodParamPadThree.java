package org.checkstyle.suppressionxpathfilter.methodparampad;

public class SuppressionXpathRegressionMethodParamPadThree {
    public void sayHello(String name) { //warn

    }
}
