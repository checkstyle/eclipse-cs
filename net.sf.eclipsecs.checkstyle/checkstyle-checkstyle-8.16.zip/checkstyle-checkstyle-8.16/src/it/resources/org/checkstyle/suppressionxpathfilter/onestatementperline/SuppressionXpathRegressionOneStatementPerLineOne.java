package org.checkstyle.suppressionxpathfilter.onestatementperline;

public class SuppressionXpathRegressionOneStatementPerLineOne {
    int i; int j; //warn
}
