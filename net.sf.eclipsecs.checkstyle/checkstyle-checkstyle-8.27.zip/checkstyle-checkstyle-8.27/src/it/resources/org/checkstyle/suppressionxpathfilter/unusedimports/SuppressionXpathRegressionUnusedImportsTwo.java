package org.checkstyle.suppressionxpathfilter.unusedimports;

import static java.util.Map.Entry; // warn

public class SuppressionXpathRegressionUnusedImportsTwo {

}
