package org.checkstyle.suppressionxpathfilter.upperell;

public class SuppressionXpathRegressionUpperEll {
    long bad = 0l;//warn
    long good = 0L;
}
