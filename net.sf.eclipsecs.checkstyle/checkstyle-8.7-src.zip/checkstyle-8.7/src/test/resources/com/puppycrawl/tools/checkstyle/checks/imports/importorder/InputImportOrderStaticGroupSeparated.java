package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import static java.lang.Math.abs;

import static java.lang.Math.cos;;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class InputImportOrderStaticGroupSeparated {
    void method() {
    }
}
