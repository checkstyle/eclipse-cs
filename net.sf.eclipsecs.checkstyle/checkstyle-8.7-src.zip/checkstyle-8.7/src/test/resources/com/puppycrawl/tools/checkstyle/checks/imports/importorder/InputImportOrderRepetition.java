package com.puppycrawl.tools.checkstyle.checks.imports;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionEvent;    //Repetitive import

import javax.swing.JComponent;
import javax.swing.JTable;

public class InputImportOrderRepetition {
}
