package com.puppycrawl.tools.checkstyle.checks.imports.customimportorder;

import java.util.Map.Entry;
import java.util.Map;

import com.google.common.*;
import com.google.common.annotations.*;

public class InputCustomImportOrderCompareImports {
}
