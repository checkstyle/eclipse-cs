package com.puppycrawl.tools.checkstyle.checks.imports.redundantimport;

import static java.util.Arrays.asList;
import static java.util.Arrays.asList;

import java.util.List;
import java.util.List;

public class InputRedundantImportCheckClearState {}
