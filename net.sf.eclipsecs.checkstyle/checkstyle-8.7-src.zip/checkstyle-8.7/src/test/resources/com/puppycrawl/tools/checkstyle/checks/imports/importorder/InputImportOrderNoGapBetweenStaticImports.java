package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import static java.lang.Math.abs;
import static java.lang.Math.cos; // no gap below
import static javax.xml.transform.TransformerFactory.newInstance;//no gap below
import static org.junit.Assert.fail;

public class InputImportOrderNoGapBetweenStaticImports {
}
