package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import static java.io.File.createTempFile;
import static java.awt.Button.ABORT;
import static javax.swing.WindowConstants.*;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.event.ActionEvent;
/***comment test***/
import java.io.IOException;
import java.io.InputStream;

import javax.swing.JComponent;
import javax.swing.JTable;

import static java.io.File.*;
import java.io.File;
import java.io.Reader;

public class InputImportOrder_Top {
}
