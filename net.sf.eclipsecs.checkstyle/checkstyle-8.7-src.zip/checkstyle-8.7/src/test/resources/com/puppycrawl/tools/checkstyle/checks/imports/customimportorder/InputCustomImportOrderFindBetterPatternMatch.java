package com.puppycrawl.tools.checkstyle.checks.imports.customimportorder;

import javax.lang.model.element.AnnotationValue;
import java.awt.event.ActionEvent;
import java.lang.*;
import java.awt.color.ColorSpace;

import com.google.common.annotations.Beta;

import com.google.common.collect.HashMultimap;

public class InputCustomImportOrderFindBetterPatternMatch {
}
