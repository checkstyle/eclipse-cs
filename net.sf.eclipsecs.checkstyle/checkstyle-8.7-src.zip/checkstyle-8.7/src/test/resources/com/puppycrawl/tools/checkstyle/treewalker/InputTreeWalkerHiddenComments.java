package com.puppycrawl.tools.checkstyle.treewalker;

/**
 * Some Javadoc.
 *
 * <p>{@code function} will never be invoked with a null value.
 *
 * @since 8.0
 */
public class InputTreeWalkerHiddenComments {

}
// inline comment
