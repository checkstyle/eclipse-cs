package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

public class InputImportOrder_NoFailureForRedundantImports {
}

