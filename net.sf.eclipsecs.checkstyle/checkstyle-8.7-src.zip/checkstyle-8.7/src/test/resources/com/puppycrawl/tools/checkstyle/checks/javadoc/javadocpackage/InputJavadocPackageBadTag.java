package com.puppycrawl.tools.checkstyle.checks.javadoc.javadocpackage;

/**
 * The following is a bad tag.
 * @mytag Hello
 */
public class InputJavadocPackageBadTag
{
}
