package com.puppycrawl.tools.checkstyle.checks.javadoc.javadocstyle.bothfiles;
