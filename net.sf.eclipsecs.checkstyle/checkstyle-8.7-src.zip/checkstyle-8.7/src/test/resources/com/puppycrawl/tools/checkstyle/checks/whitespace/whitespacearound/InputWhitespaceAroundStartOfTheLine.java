package com.puppycrawl.tools.checkstyle.checks.whitespace.whitespacearound;

public class InputWhitespaceAroundStartOfTheLine {
 public void checkSmth(
){
  final int SOMETHING = 1;
 }
}
