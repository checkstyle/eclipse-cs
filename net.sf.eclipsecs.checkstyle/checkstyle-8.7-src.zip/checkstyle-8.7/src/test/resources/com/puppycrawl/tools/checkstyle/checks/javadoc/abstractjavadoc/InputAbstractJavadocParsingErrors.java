package com.puppycrawl.tools.checkstyle.checks.javadoc.abstractjavadoc;

/**
 * <unclosedTag>
 */
class InputAbstractJavadocParsingErrors {
    /**
     * <img src="singletonTag"/></img>
     */
    void singletonTag() {
    }
}
