package com.puppycrawl.tools.checkstyle.utils.blockcommentposition;

/**
 * I'm a javadoc
 */
public class InputBlockCommentPositionOnClass {

}

/**
 * I'm a javadoc
 */
class JavaDocOnClass1 {
}


/**
 * I'm a javadoc
 */
@Deprecated
class JavaDocOnClass2 {
}

