package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import static org.junit.Assert.fail;
import static javax.xml.transform.TransformerFactory.newInstance;
import static java.lang.Math.cos;
import static java.lang.Math.abs;

public class InputImportOrderSortStaticImportsAlphabetically {
}
