package com.puppycrawl.tools.checkstyle.checks.whitespace.parenpad;

public class InputParenPadStartOfTheLine {
public String checkSmth( String
a) {
    return a + 1;
   }
}
