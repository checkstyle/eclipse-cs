package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import java.awt.Button;
import static java.awt.Button.ABORT;
import java.awt.Frame;
import java.awt.Dialog;
import java.awt.event.ActionEvent;

import javax.swing.JComponent;
import static javax.swing.WindowConstants.HIDE_ON_CLOSE;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import static javax.swing.WindowConstants.*;
import javax.swing.JTable;

import static java.io.File.createTempFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

public class InputImportOrder_InFlow {
}
