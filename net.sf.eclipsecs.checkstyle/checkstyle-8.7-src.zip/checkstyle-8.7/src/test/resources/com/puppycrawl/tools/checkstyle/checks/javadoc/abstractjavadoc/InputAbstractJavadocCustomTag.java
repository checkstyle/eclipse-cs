package com.puppycrawl.tools.checkstyle.checks.javadoc.abstractjavadoc;

public class InputAbstractJavadocCustomTag {
    /**
     * {@customTag}
     */
    void customTag() {}

    /** {@customTag} */
    void customTag2() {}
}
