package com.puppycrawl.tools.checkstyle.checker;
/*comment*/
public class InputChecker {
}
class InputCheckerInner {
}
