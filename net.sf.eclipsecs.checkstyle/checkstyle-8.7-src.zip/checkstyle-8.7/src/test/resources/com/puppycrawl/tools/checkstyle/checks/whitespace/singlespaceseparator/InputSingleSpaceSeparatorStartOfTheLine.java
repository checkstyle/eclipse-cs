package com.puppycrawl.tools.checkstyle.checks.whitespace.singlespaceseparator;

public class InputSingleSpaceSeparatorStartOfTheLine {
    int
   i  = 0;
}
