package com.puppycrawl.tools.checkstyle.checks.header.regexpheader;

import java.awt.*;

/**
 * Some doc.
 */

public class InputRegexpHeaderDefaultConfig
{
}
