package com.puppycrawl.tools.checkstyle.checks.whitespace.nowhitespaceafter;

public class InputNoWhitespaceAfterFormerNpe
{
    private int[] getSome() {
        return new int[4];
    }
}
