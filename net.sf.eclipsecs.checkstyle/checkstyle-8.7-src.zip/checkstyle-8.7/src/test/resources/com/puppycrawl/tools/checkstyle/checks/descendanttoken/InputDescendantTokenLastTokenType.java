package com.puppycrawl.tools.checkstyle.checks.descendanttoken;

/**
 * Created by valeria on 8/19/17.
 */
public class InputDescendantTokenLastTokenType {}
