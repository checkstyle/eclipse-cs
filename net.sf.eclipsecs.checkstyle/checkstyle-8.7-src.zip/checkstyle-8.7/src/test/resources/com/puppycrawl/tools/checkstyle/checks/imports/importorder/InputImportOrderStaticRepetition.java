package com.puppycrawl.tools.checkstyle.checks.imports;

import static java.lang.Math.*;
import static org.antlr.v4.runtime.CommonToken.*;
import static org.antlr.v4.runtime.CommonToken.*;  //Repetitive static import

import java.util.Set;

import org.junit.Test;

public class InputImportOrderStaticRepetition {
}
