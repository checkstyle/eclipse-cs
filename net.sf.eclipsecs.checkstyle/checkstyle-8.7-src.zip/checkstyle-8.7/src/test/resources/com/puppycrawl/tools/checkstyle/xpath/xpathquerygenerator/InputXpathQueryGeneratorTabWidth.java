package com.puppycrawl.tools.checkstyle.xpath.xpathquerygenerator;

public class InputXpathQueryGeneratorTabWidth {
			public String toString() {
				return "";
			}

			public		void getName() {

			}

			private int tabAfterMe()	{
				return 1;
			}

			private String endLineTab = "qwe";


}
