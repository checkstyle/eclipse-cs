package org.checkstyle.suppressionxpathfilter.whitespacearound;

public class SuppressionXpathRegressionWhitespaceAroundNotFollowed {
    int bad =0; //warn
    int good = 0;
}
