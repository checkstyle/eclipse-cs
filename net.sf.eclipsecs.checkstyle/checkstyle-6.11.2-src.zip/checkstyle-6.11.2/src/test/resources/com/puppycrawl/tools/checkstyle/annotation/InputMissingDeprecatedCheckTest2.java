package com.puppycrawl.tools.checkstyle.annotation;

public class InputMissingDeprecatedCheckTest2 {


    /**
     * @deprecated
     * 
     * @param comment
     */
    public void method(){
    }

}