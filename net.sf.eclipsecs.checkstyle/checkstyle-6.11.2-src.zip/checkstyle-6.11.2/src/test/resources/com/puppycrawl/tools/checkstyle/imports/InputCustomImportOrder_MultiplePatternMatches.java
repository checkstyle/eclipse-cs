package com.puppycrawl.tools.checkstyle.imports;

import org.junit.Test;

public class InputCustomImportOrder_MultiplePatternMatches {
}
