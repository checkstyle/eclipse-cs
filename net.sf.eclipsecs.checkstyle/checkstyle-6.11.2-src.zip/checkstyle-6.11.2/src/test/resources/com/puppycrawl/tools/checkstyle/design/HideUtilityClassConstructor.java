package com.puppycrawl.tools.checkstyle.design;

public class HideUtilityClassConstructor {
    
    protected HideUtilityClassConstructor() {
        //does nothing
    }
}
