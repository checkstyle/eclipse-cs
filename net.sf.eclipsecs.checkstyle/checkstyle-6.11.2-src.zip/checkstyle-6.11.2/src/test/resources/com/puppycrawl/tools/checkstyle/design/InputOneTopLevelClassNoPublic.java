package com.puppycrawl.tools.checkstyle.design;

class InputOneTopLevelClassNoPublic
{

}

class InputOneTopLevelClassNoPublic2
{

}