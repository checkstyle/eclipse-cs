package com.puppycrawl.tools.checkstyle.imports;

import static java.lang.Math.*;
import static org.antlr.v4.runtime.CommonToken.*;

import org.*;

import java.util.Set;
import org.junit.Test;

public class InputImportOrderStaticOnDemandGroupOrder
{

}
