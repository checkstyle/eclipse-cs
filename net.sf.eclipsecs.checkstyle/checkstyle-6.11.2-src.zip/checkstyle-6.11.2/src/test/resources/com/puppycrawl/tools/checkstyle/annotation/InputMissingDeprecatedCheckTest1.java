package com.puppycrawl.tools.checkstyle.annotation;

import java.lang.annotation.Inherited;
/**
 * 
 * @author idubinin
 *@deprecated
 *@deprecated
 *stuff
 *stuff
 */
public class InputMissingDeprecatedCheckTest1
{
    
}
