package com.puppycrawl.tools.checkstyle.design;

interface InputOneTopLevelInterface2inner1 {
    int foo();
}

public interface InputOneTopLevelInterface2 {
    int foo();
}

interface InputOneTopLevelInterface2inner2 {
    int foo();
}
