package com.puppycrawl.tools.checkstyle; class inputHeader {} // One line test
