package com.puppycrawl.tools.checkstyle.whitespace;

public class InputEmptyLineSeparatorMultipleFieldsInClass
{
    int first;
    int second;
}
