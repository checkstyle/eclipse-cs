package com.puppycrawl.tools.checkstyle.imports;


public class InputCustomImportOrder_NoImports {
}
