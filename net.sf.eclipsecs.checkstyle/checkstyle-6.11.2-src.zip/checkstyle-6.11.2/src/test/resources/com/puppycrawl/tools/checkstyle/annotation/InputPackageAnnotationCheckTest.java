package com.puppycrawl.tools.checkstyle.annotation;

@Deprecated
public class InputPackageAnnotationCheckTest {
	
}
