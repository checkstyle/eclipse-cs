package com.puppycrawl.tools.checkstyle.imports;

import java.io.File;

import org.*;
import org.myOrgorgan.Test;

public class InputImportOrder_WildcardUnspecified {
}
