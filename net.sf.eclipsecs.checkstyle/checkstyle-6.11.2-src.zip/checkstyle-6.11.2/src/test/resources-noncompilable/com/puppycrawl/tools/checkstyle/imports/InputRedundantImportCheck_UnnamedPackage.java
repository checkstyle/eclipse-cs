import java.util.List;
import java.util.List;
import java.util.Arrays;
import java.lang.String;
import static java.lang.Math.PI;

public class InputRedundantImportCheck_UnnamedPackage
{
    public static double pi=PI;
    public List myList;
}
