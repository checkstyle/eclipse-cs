//no package
class Input {
    Boolean obj = new Boolean();
    Integer obj = new Integer();
}