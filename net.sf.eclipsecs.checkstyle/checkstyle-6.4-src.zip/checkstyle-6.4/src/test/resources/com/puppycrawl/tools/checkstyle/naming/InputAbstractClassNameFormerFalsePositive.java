package com.puppycrawl.tools.checkstyle.naming;

public class InputAbstractClassNameFormerFalsePositive
{
    class Abstract {
        
    }
    
    class AbstractClass {
        
    }
}
