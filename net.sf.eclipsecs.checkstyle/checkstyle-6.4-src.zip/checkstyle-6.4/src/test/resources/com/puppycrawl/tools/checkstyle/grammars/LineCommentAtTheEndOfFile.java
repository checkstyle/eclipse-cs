package com.puppycrawl.tools.checkstyle.grammars;

public class LineCommentAtTheEndOfFile
{
} // EOF on this line