package com.puppycrawl.tools.checkstyle.naming;

class inputHeaderClass {

    public interface inputHeaderInterface {};
//comment
    public enum inputHeaderEnum { one, two };

    public @interface inputHeaderAnnotation {};

}
