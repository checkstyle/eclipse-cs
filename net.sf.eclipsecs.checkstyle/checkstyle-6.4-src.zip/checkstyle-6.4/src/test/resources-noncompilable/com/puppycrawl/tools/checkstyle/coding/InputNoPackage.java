/**
 * No package here. Compilable by javac, but noncompilable by eclipse
 */
public class InputNoPackage {
}
