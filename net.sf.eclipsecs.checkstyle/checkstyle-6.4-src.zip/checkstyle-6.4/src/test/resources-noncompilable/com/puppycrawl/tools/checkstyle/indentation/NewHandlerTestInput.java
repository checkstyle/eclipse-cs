package com.puppycrawl.tools.checkstyle.indentation;

/**
 *
 * @author  IljaDubinin
 */
public class NewHandlerTestInput 
{
    
    public static void test() {
        method(ArrayList::new);
    }
    
}
