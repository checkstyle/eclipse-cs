package com.puppycrawl.tools.checkstyle;

public class InputMain {
}
class InputMainInner {
}
