package com.puppycrawl.tools.checkstyle.design;

public enum InputOneTopLevelEnum {
    VALUE1, VALUE2;
}
