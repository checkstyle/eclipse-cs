package com.puppycrawl.tools.checkstyle.design;

public interface InputOneTopLevelInterface {
    int foo();
}
