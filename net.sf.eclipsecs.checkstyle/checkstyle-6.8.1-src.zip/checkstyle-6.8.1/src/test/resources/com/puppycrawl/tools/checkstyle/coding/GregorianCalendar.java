package com.puppycrawl.tools.checkstyle.coding;

public class GregorianCalendar
{
    class SubCalendar {
        
    }
}
