package com.puppycrawl.tools.
    checkstyle.whitespace;

import com.google.common.annotations.Beta;

import javax.accessibility.
    AccessibleAttributeSequence;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public class
    NoLineWrapBadInput {
    
	public void
	    fooMethod() {
		final int
		    foo = 0;
	}
}

enum
    FooFoo {
}

interface
    InterFoo {}


