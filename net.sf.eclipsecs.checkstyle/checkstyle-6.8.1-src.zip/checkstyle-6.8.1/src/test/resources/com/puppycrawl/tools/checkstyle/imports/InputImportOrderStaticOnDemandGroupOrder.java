package com.puppycrawl.tools.checkstyle.imports;

import static java.lang.Math.*;
import static org.abego.treelayout.Configuration.*;

import org.*;

import java.util.Set;

public class InputImportOrderStaticOnDemandGroupOrder
{

}
