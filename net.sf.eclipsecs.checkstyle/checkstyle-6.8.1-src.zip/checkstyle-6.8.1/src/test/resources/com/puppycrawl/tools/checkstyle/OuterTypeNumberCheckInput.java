package com.puppycrawl.tools.checkstyle;

/**Contains empty inner class for OuterTypeNumberCheckTest*/
public class OuterTypeNumberCheckInput {

    /** Just empty inner class*/
    private class InnerClass {
        // Do nothing
    }
}
