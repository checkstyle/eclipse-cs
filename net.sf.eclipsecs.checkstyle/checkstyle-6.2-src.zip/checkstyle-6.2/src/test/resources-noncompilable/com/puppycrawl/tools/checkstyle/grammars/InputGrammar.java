//Noncompilable until project's encoding would be set to UTF-8 (pom.xml line: 150)
package com.puppycrawl.tools.checkstyle.grammars;
/**
 * Input for grammar test.
 */
public class InputGrammar
{
    int é = 1; // illegal, unless UTF-8
}
