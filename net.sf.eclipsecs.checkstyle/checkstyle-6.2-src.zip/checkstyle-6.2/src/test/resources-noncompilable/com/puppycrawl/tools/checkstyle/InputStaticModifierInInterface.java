//Compilable with Java8
public interface InputStaticModifierInInterface
{
    static int f()
    {
        int someName = 5;
        return someName;
    }
}
