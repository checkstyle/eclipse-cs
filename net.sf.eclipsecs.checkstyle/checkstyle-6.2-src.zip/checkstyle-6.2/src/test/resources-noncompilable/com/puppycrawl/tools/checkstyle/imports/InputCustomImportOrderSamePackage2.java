//Moved to noncompilable because UT requires imports from the same package
package java.util.concurrent;
import java.util.regex.Pattern;
import java.util.List;
import java.util.regex.Matcher;
import java.util.StringTokenizer;
import java.util.*;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.*;

public class InputCustomImportOrderSamePackage2 {
}
