@Deprecated // non-compilable annotation
package com.puppycrawl.tools.checkstyle.checks.annotation;

public class InputPackageAnnotation2 {
	
}
