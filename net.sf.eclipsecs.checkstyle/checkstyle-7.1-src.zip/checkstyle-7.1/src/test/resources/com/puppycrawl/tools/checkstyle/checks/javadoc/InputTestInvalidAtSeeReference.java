package com.puppycrawl.tools.checkstyle.checks.javadoc;

/**
 * @see javax.swing.tree.DefaultTreeCellRenderer.getTreeCellRendererComponent()
 */
class InputTestInvalidAtSeeReference {
}
