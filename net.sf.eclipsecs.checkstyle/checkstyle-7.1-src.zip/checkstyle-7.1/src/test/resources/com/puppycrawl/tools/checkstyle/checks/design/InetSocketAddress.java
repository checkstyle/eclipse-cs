package com.puppycrawl.tools.checkstyle.checks.design;
// ATTENTION: we need name of this class to be without "Input" prefix to as we
// need the same name as defined at VisibilityModifierCheck.DEFAULT_IMMUTABLE_TYPES
public class InetSocketAddress
{
    class Arrays {
        
    }
}
