package com.puppycrawl.tools.checkstyle.checks.javadoc;

import com.google.common.base.Function;

class Foo5 {

    /**
     * This class implements the GWT serialization of {@link HashMultimap}.
     * 
     * @author Jord Sonneveld
     * 
     */
  public static <T extends Enum<T>> Function<String, T> valueOfFunction(
      Class<T> enumClass) {
    return null;
  }
}