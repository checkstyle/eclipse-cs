package com.google.checkstyle.test.chapter4formatting.rule42blockindentaion;

public class InputFastMatcher
{

    public boolean matches(char c)
    {
        // TODO Auto-generated method stub
        return false;
    }

    public String replaceFrom(CharSequence sequence, CharSequence replacement)
    {
        // TODO Auto-generated method stub
        return null;
    }

    public String collapseFrom(CharSequence sequence, char replacement)
    {
        // TODO Auto-generated method stub
        return null;
    }

    public String trimFrom(CharSequence s)
    {
        // TODO Auto-generated method stub
        return null;
    }

    public String trimLeadingFrom(CharSequence sequence)
    {
        // TODO Auto-generated method stub
        return null;
    }

    public String trimTrailingFrom(CharSequence sequence)
    {
        // TODO Auto-generated method stub
        return null;
    }

}
