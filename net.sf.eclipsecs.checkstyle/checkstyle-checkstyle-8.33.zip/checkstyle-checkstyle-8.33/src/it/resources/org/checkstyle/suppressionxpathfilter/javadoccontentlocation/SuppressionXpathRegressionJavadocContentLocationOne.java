package org.checkstyle.suppressionxpathfilter.javadoccontentlocation;

public interface SuppressionXpathRegressionJavadocContentLocationOne {

    /** Text. // warn
     */
    void test();
}
