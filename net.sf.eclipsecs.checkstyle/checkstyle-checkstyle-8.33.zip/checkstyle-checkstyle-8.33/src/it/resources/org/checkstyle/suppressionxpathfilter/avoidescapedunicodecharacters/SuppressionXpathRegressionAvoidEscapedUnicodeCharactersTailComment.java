package org.checkstyle.suppressionxpathfilter.avoidescapedunicodecharacters;

public class SuppressionXpathRegressionAvoidEscapedUnicodeCharactersTailComment {
    /* warn */ private String unitAbbrev9 = "\u03bcs";
    String unitAbbrev = "\u03bcs"; // Greek letter mu, "s"
}
