package org.checkstyle.suppressionxpathfilter.customimportorder;

import static java.util.Arrays.sort;
import static java.lang.Math.PI;
import java.io.File; // warn
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Scanner;

public class SuppressionXpathRegressionCustomImportOrderTwo {
    // code
}
