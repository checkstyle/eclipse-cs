package org.checkstyle.suppressionxpathfilter.javadoctype;

/**
 * Has an author tag but wrong format.
 * @author bar
 */
public class SuppressionXpathRegressionJavadocTypeTwo { //warn

}
