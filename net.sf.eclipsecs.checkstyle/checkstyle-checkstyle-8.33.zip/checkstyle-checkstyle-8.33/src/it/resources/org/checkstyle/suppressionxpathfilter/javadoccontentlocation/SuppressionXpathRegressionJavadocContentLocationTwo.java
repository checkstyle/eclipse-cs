package org.checkstyle.suppressionxpathfilter.javadoccontentlocation;

public interface SuppressionXpathRegressionJavadocContentLocationTwo {

    /* warn */ /**
     * Text.
     */
    void test();
}
