package org.checkstyle.suppressionxpathfilter.invalidjavadocposition;

@SuppressWarnings("serial")
/** // warn
 * Javadoc Comment
 */
public class SuppressionXpathRegressionInvalidJavadocPositionOne {
}
