package org.checkstyle.suppressionxpathfilter.multiplevariabledeclarations;

public class SuppressionXpathRegressionMultipleVariableDeclarationOne {
    int i, j; //warn
}
