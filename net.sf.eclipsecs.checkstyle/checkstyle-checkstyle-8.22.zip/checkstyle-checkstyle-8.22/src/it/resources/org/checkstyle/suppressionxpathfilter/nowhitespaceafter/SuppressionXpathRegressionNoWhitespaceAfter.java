package org.checkstyle.suppressionxpathfilter.nowhitespaceafter;

public class SuppressionXpathRegressionNoWhitespaceAfter {
    int bad = - 1;//warn
    int good = -1;
}
