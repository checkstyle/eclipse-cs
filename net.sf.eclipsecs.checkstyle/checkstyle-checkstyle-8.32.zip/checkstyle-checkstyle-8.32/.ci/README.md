ATTENTION:
  All scripts in this folder expect to be launched from root folder of repository

Example of usage:
  ./.ci/travis/travis.sh all-sevntu-checks

  export TRAVIS_PULL_REQUEST="" && ./.ci/travis/travis.sh releasenotes-gen
