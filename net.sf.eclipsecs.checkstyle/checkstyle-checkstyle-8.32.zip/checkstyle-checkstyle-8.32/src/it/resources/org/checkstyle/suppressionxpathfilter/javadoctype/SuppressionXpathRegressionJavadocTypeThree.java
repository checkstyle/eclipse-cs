package org.checkstyle.suppressionxpathfilter.javadoctype;

/**
 * Need type param tags.
 * @param <A>
 * @param <B>
 */
public class SuppressionXpathRegressionJavadocTypeThree<A, B, C> { //warn

}
