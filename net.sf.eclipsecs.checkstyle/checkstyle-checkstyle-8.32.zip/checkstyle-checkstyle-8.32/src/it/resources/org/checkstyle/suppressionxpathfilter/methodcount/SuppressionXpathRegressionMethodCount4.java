package org.checkstyle.suppressionxpathfilter.methodcount;

class SuppressionXpathRegressionMethodCount4 { // warn
    public void foo() {}
    public void foo1() {}
}
