package org.checkstyle.suppressionxpathfilter.methodcount;

class SuppressionXpathRegressionMethodCount2 { // warn
    private void foo() {}
    private void foo1() {}
}
