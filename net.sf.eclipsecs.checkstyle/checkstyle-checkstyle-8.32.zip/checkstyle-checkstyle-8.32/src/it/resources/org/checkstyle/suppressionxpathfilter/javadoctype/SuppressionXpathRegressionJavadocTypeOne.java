package org.checkstyle.suppressionxpathfilter.javadoctype;

/**
 * Needs an author tag.
 */
public class SuppressionXpathRegressionJavadocTypeOne { //warn

}
