package org.checkstyle.suppressionxpathfilter.invalidjavadocposition;

public class SuppressionXpathRegressionInvalidJavadocPositionSix {
	int a;
    /** // warn
     * Javadoc Comment
     */
}
