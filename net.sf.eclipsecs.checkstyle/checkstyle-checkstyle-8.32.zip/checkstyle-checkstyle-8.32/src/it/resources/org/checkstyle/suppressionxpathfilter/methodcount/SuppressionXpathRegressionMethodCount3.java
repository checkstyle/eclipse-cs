package org.checkstyle.suppressionxpathfilter.methodcount;

class SuppressionXpathRegressionMethodCount3 { // warn
    protected void foo() {}
    protected void foo1() {}
}
