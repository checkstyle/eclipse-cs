package org.checkstyle.suppressionxpathfilter.missingctor;

public class SuppressionXpathRegressionMissingCtor1 { // warn

}
