package org.checkstyle.suppressionxpathfilter.missingctor;

public class SuppressionXpathRegressionMissingCtor2 {

    private SuppressionXpathRegressionMissingCtor2() {

    }

    class InnerClass { // warn

    }

}
