package org.checkstyle.suppressionxpathfilter.missingjavadocmethod;

public class SuppressionXpathRegressionMissingJavadocMethod2 {
    public void foo() { // warn
        // code
    }
}
