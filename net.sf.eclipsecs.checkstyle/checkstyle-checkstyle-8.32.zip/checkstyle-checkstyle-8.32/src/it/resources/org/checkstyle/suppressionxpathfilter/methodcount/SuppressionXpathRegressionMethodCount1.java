package org.checkstyle.suppressionxpathfilter.methodcount;

class SuppressionXpathRegressionMethodCount1 { // warn
    void foo() {}
    void foo1() {}
}
