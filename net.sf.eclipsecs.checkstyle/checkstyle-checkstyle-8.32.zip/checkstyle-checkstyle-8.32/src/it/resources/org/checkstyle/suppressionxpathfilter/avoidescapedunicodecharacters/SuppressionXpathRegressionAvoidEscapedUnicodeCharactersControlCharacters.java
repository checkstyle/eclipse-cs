package org.checkstyle.suppressionxpathfilter.avoidescapedunicodecharacters;

public class SuppressionXpathRegressionAvoidEscapedUnicodeCharactersControlCharacters {
    private String unitAbbrev9 = "\u03bcs"; /* warn */
    private String nonPrintableCharacter = "\u0008";
}
