package org.checkstyle.suppressionxpathfilter.invalidjavadocposition;

public class SuppressionXpathRegressionInvalidJavadocPositionTwo {
}
/** // warn
 * Javadoc comment
 */
