package org.checkstyle.suppressionxpathfilter.missingjavadocmethod;

public class SuppressionXpathRegressionMissingJavadocMethod1 {
    public SuppressionXpathRegressionMissingJavadocMethod1() { // warn
        // code
    }
}
