package com.google.checkstyle.test.chapter3filestructure.rule341onetoplevel;

class InputOneTopLevelClassBad1 {} //ok
enum FooEnum {} // warn
@interface FooAt {} // warn
