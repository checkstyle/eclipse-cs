package com.google.checkstyle.test.chapter3filestructure.rule333orderingandspacing;

import static java.awt.Button.ABORT;
import static java.io.File.createTempFile;


import static javax.swing.WindowConstants.*; //warn

import com.google.checkstyle.test.chapter2filebasic.rule21filename.*;
import com.google.checkstyle.test.chapter3filestructure.rule3sourcefile.*;
import com.google.common.reflect.*;
import java.util.List;


import java.util.StringTokenizer; //warn

import java.util.concurrent.AbstractExecutorService; // warn

public class InputCustomImportOrder4 {
}
