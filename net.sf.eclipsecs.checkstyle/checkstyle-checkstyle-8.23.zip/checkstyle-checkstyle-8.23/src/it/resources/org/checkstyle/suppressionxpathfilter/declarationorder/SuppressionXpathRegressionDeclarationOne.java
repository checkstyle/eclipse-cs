package org.checkstyle.suppressionxpathfilter.declarationorder;

public class SuppressionXpathRegressionDeclarationOne {
    private int age;
    public String name;  //warn
}
