package org.checkstyle.suppressionxpathfilter.noenumtrailingcomma;

public class SuppressionXpathRegressionNoEnumTrailingCommaTwo {

    enum Foo6 { FOO, BAR,; } //warn
}
