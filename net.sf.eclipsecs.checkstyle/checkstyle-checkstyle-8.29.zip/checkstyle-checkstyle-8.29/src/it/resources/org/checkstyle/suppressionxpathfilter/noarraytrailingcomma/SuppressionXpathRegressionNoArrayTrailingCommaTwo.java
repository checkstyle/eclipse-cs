package org.checkstyle.suppressionxpathfilter.noarraytrailingcomma;

public class SuppressionXpathRegressionNoArrayTrailingCommaTwo {
    int[] t4 = new int[] {1,}; //warn
}
