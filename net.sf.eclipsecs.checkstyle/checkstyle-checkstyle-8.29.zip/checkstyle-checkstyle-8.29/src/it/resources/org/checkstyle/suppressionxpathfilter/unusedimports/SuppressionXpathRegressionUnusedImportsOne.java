package org.checkstyle.suppressionxpathfilter.unusedimports;

import java.util.List; // warn

public class SuppressionXpathRegressionUnusedImportsOne {

}
