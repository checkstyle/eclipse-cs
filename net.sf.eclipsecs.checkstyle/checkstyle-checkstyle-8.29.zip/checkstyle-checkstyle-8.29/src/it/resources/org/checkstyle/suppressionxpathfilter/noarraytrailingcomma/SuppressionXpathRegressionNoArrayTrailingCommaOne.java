package org.checkstyle.suppressionxpathfilter.noarraytrailingcomma;

public class SuppressionXpathRegressionNoArrayTrailingCommaOne {

    int[] t1 = new int[] {1, 2, 3, 4, }; //warn

}
