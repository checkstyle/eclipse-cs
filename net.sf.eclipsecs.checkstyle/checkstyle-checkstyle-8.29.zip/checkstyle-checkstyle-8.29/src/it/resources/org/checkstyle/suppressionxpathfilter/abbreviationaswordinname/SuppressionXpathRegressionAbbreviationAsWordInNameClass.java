package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public class SuppressionXpathRegressionAbbreviationAsWordInNameClass {

    class CLASS { // warn

    }

}
