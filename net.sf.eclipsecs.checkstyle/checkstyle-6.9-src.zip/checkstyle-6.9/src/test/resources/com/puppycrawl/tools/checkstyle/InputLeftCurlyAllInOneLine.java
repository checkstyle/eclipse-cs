package com.puppycrawl.tools.checkstyle;import java.lang.annotation.ElementType;import java.lang.annotation.Target;import java.util.ArrayList;import java.util.List;class InputLeftCurlyAllInOneLine{
    
   
}
