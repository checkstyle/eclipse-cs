package com.puppycrawl.tools.checkstyle.coding;

class InputPackageDeclaration {
    public String value;
    
    private void get(){
    }
}