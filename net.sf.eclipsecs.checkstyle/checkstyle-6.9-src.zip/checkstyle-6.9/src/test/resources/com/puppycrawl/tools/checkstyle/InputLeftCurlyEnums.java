package com.puppycrawl.tools.checkstyle;

public class InputLeftCurlyEnums {
    enum Colors {RED,
        BLUE,
        GREEN
    }

    enum Languages {
        JAVA,
        PHP,
        SCALA,
        C,
        PASCAL
    }
}
