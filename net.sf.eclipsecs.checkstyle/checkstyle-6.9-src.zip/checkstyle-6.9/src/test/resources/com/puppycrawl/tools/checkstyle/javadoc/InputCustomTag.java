package com.puppycrawl.tools.checkstyle.javadoc;

public class InputCustomTag {
    /**
     * {@customTag}
     */
    void customTag() {}
}
