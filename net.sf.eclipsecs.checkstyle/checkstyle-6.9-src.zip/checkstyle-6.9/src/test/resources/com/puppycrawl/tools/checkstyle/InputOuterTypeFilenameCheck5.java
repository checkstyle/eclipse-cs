// someexamples of 1.5 extensions
package com.puppycrawl.tools.checkstyle;

 class InputOuterTypeFilenameCheckWrongName2 {
    
  
}