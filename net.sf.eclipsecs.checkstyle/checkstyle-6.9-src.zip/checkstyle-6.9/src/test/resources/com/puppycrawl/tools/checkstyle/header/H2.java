/*
 * (C) '06 incorrect header
 */

package com.puppycrawl.tools.checkstyle.header;

public class H2
{
}
