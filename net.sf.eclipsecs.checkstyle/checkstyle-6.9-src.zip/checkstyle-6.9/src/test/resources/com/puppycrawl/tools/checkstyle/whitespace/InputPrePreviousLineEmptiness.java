
package com.puppycrawl.tools.checkstyle.whitespace;

public class InputPrePreviousLineEmptiness {

}
