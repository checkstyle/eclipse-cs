package com.puppycrawl.tools.checkstyle.javadoc;

public class InputLoadErrors
{
    /**
     * aasdf
     * @throws InvalidExceptionName exception that cannot be loaded
     */
    void method() {}
}
