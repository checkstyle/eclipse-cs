package com.puppycrawl.tools.checkstyle.javadoc;

/**
 * <unclosedTag>
 */
class InputParsingErrors {
    /**
     * <img src="singletonTag"/></img>
     */
    void singletonTag() {
    }
}
