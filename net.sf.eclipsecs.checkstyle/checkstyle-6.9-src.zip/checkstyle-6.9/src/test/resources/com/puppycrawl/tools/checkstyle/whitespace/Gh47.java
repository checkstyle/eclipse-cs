package com.puppycrawl.tools.checkstyle.whitespace;

import java.util.List;

public class Gh47
{
    public List<List<String>[]> listOfListOFArrays;
}
