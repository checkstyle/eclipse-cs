package com.puppycrawl.tools.checkstyle.imports;

import javax.xml.transform.Source;

import org.w3c.dom.Node;

class DOMSource {}
