package com.puppycrawl.tools.checkstyle.imports;

import static java.io.File.createTempFile;
import static java.awt.Button.ABORT;
import static javax.swing.WindowConstants.*;

import com.puppycrawl.tools.*;
import java.util.StringTokenizer;
import java.util.*;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.*;

import com.puppycrawl.tools.*;
import com.*;

import com.google.common.*;
import org.junit.*;

public class InputCustomImportOrder3 {
}
