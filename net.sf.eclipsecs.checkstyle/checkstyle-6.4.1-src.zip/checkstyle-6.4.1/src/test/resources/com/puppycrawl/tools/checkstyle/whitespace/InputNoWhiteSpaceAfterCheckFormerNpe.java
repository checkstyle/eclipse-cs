package com.puppycrawl.tools.checkstyle.whitespace;

public class InputNoWhiteSpaceAfterCheckFormerNpe
{
    private int[] getSome() {
        return new int[4];
    }
}
