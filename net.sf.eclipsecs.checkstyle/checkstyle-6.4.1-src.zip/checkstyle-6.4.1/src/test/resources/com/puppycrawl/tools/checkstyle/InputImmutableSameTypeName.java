package com.puppycrawl.tools.checkstyle;

import com.puppycrawl.tools.checkstyle.coding.GregorianCalendar;
import com.puppycrawl.tools.checkstyle.InetSocketAddress;
public final class InputImmutableSameTypeName
{
    public final java.util.GregorianCalendar calendar = null;
    public final GregorianCalendar calendar2 = null;
    public final com.puppycrawl.tools.checkstyle.coding.GregorianCalendar calendar3 = null;
    public final InetSocketAddress address = null;
    public final java.net.InetSocketAddress adr = null;
}
