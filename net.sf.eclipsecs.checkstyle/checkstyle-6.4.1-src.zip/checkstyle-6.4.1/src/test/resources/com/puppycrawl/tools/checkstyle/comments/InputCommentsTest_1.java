package com.puppycrawl.tools.checkstyle.comments;
public class /*
    i'mcomment567
    */
InputCommentsTest_1
{ // comment to left curly brace
}
