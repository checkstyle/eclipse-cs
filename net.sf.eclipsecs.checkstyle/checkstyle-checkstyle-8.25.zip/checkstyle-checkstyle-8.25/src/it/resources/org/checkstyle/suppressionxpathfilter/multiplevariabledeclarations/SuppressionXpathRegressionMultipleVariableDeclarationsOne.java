package org.checkstyle.suppressionxpathfilter.multiplevariabledeclarations;

public class SuppressionXpathRegressionMultipleVariableDeclarationsOne {
    int i, j; //warn
}
