package org.checkstyle.suppressionxpathfilter.unnecessarysemicolonaftertypememberdeclaration;

public class SuppressionXpathRegressionUnnecessarySemicolonAfterTypeMemberDeclaration {
    void method(){}; //warn
}
