package org.checkstyle.suppressionxpathfilter.outertypefilename;

class Class1 { // warn

}
