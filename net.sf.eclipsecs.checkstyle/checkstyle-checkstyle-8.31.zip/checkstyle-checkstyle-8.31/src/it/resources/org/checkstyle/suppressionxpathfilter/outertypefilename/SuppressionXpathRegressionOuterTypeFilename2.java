package org.checkstyle.suppressionxpathfilter.outertypefilename;

class Test { // warn
    public interface NestedInterface {}
    public enum NestedEnum {}
    class NestedClass {}
}
