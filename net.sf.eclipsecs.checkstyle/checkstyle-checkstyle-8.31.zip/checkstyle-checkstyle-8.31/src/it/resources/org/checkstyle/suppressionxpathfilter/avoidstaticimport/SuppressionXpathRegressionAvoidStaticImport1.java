package org.checkstyle.suppressionxpathfilter.avoidstaticimport;

import static javax.swing.WindowConstants.*; // warn

public class SuppressionXpathRegressionAvoidStaticImport1 {
}
