package org.checkstyle.suppressionxpathfilter.nolinewrap;

public class SuppressionXpathRegressionNoLineWrap3 {
    SuppressionXpathRegressionNoLineWrap3 //warn
            (String input1, String input2) {

    }
}
