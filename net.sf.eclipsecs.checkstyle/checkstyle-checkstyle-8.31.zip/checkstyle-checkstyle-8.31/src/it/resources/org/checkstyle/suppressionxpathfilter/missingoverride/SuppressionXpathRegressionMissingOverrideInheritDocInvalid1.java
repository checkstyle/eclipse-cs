package org.checkstyle.suppressionxpathfilter.missingoverride;

public class SuppressionXpathRegressionMissingOverrideInheritDocInvalid1 {
    /**
     * {@inheritDoc}
     */
    private void test() { // warn

    }
}
