package org.checkstyle.suppressionxpathfilter.nolinewrap;

public class SuppressionXpathRegressionNoLineWrap2 {
    public static // warn
        void test2() {
                       
    }
}
