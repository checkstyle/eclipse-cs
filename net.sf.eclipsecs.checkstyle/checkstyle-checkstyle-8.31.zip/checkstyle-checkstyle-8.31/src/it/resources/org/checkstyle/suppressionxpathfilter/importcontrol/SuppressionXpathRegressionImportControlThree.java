package org.checkstyle.suppressionxpathfilter.importcontrol; //warn

public class SuppressionXpathRegressionImportControlThree {
}
