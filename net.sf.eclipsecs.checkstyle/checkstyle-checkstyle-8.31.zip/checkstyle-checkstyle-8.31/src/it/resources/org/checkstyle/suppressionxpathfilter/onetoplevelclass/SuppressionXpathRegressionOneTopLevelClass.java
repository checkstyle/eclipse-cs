package org.checkstyle.suppressionxpathfilter.onetoplevelclass;

public class SuppressionXpathRegressionOneTopLevelClass {
    // methods
}

class ViolatingSecondClass { //warn
    // methods
}
