package org.checkstyle.suppressionxpathfilter.leftcurly;

public class SuppressionXpathRegressionLeftCurlyOne
{ //warn
}
