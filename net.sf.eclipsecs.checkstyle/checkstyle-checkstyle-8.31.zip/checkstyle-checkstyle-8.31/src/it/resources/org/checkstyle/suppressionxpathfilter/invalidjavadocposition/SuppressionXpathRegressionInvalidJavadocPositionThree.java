package org.checkstyle.suppressionxpathfilter.invalidjavadocposition;

public class SuppressionXpathRegressionInvalidJavadocPositionThree {
    public void foo(){
    }
    /** // warn
     * Javadoc comment
     */
}
