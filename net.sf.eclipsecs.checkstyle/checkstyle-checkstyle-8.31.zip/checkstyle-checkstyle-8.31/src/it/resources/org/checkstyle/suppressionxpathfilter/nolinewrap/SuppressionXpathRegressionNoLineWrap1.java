package org.checkstyle.suppressionxpathfilter // warn
        .nolinewrap;

public class SuppressionXpathRegressionNoLineWrap1 {
}
