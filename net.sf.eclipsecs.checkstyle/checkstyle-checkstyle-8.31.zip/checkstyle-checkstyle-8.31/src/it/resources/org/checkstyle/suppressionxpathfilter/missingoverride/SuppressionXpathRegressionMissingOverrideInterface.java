package org.checkstyle.suppressionxpathfilter.missingoverride;

public interface SuppressionXpathRegressionMissingOverrideInterface {
    /**
     * {@inheritDoc}
     */
    boolean test(Object obj); // warn
}
