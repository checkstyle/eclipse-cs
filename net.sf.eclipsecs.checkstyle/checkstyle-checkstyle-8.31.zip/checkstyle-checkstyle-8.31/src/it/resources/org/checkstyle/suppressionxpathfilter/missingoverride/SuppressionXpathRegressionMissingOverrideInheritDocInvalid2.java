package org.checkstyle.suppressionxpathfilter.missingoverride;

public class SuppressionXpathRegressionMissingOverrideInheritDocInvalid2 {
    /**
     * {@inheritDoc}
     */
    public static void test() { // warn

    }
}
