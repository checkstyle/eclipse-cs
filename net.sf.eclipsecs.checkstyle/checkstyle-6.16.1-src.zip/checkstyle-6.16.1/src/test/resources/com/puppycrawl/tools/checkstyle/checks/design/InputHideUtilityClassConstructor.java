package com.puppycrawl.tools.checkstyle.checks.design;

public class InputHideUtilityClassConstructor {
    
    protected InputHideUtilityClassConstructor() {
        //does nothing
    }
}
