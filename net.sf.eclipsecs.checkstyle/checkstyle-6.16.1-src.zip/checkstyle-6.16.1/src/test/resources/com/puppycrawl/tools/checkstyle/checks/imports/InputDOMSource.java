package com.puppycrawl.tools.checkstyle.checks.imports;

import javax.xml.transform.Source;

import org.w3c.dom.Node;

class InputDOMSource {}
