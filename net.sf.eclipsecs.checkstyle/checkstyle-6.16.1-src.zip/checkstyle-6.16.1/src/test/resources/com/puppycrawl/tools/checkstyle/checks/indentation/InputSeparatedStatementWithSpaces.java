// test file has no expected comments to test out blank line with just spaces
package com.puppycrawl.tools.checkstyle.checks.indentation;

import java.util.*
    // next line should be empty with just spaces, indented correctly
    
    ;

public class InputSeparatedStatementWithSpaces {
}