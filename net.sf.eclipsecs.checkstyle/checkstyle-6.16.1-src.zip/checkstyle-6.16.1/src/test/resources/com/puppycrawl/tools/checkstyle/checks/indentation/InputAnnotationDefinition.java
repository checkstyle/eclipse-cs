package com.puppycrawl.tools.checkstyle.checks.indentation; //indent:0 exp:0

@interface AnnotationDefinition { //indent:0 exp:0
    int value = 1; //indent:4 exp:4
} //indent:0 exp:0
