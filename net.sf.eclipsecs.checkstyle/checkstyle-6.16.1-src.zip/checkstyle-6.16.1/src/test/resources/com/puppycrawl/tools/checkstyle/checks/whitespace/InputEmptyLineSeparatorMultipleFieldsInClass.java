package com.puppycrawl.tools.checkstyle.checks.whitespace;

public class InputEmptyLineSeparatorMultipleFieldsInClass
{
    int first;
    int second;
}
