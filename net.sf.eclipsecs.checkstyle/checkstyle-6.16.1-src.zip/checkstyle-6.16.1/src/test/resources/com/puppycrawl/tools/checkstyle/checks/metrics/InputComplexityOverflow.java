package com.puppycrawl.tools.checkstyle.checks.metrics;

/**
 * This class has methods that have an NPath complexity larger than MAXINT.
 * Test case for bug 1654769.  
 */
public class InputComplexityOverflow {

    public void provokeNpathIntegerOverflow()
    {
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (true) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}