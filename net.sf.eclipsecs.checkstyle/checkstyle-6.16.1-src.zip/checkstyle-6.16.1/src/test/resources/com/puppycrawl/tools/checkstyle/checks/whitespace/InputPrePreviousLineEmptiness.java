
package com.puppycrawl.tools.checkstyle.checks.whitespace;

public class InputPrePreviousLineEmptiness {

}
