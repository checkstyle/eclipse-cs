package com.puppycrawl.tools.checkstyle.grammars;

import java.util.Arrays;
; 
import java.util.ArrayList;
/**
 * Compilable by javac, but noncompilable by eclipse due to
 * this <a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=425140">bug</a>
 */
public class SemicolonBetweenImports
{
}
