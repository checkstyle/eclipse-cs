// no package

import java.util.List;
import java.util.List;
import java.util.Arrays;
import java.lang.String;
import static java.lang.Math.PI;

public class InputUnusedImportsFileInUnnamedPackage
{
    public static double pi=PI;
    public List myList;
}
