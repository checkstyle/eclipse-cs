package com.puppycrawl.tools.checkstyle.checks.imports;

import static io.netty.handler.codec.http.HttpConstants.COLON;
import static io.netty.handler.codec.http.HttpHeaders.addHeader;
import static io.netty.handler.codec.http.HttpHeaders.setHeader;
import static io.netty.handler.codec.http.HttpHeaders.Names.addDate;
import static io.netty.handler.codec.http.HttpHeaders.NAMES.DATE;

public class InputImportOrderEclipseStaticCaseSensitive {
}
