@Deprecated // non-compilable annotation
package com.puppycrawl.tools.checkstyle.checks.annotation.packageannotation;

public class InputPackageAnnotation2 {
	
}
