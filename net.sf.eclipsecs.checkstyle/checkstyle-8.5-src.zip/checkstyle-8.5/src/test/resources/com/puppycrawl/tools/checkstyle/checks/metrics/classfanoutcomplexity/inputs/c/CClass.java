package com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity.inputs.c;

public class CClass {
}
