package com.puppycrawl.tools.checkstyle.xpath.xpathmapper;

public class InputXpathMapperAst {

    /**
     * Returns if current node has children.
     * @return if current node has children
     */
    public void callSomeMethod() {
        int variable = 123;
        String another = "HelloWorld";
        String[] array = new String[3];
        for (String cycle : array) {

        }
    }

    /**
     * Returns if current node has children.
     * @return if current node has children
     */
    public String getSomeMethod() {
        return "HelloWorld";
    }
}
