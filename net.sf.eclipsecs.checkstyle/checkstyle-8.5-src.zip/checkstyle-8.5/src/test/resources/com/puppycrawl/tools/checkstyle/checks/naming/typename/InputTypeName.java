package com.puppycrawl.tools.checkstyle.checks.naming.typename;

class inputHeaderClass {

    public interface inputHeaderInterface {};
//comment
    public enum inputHeaderEnum { one, two };

    public @interface inputHeaderAnnotation {};

}
