package com.puppycrawl.tools.checkstyle.filters.suppresswarningsfilter;

public class InputSuppressWarningsFilterById {

    @SuppressWarnings("checkstyle:ignore")
    private int A1 = 1;

    @SuppressWarnings("checkstyle:ignore")
    public static void main(String[] args) {

    }

}
