package com.puppycrawl.tools.checkstyle.checks.javadoc.javadocmethod;

public class InputJavadocMethodLoadErrors
{
    /**
     * aasdf
     * @throws InvalidExceptionName exception that cannot be loaded
     */
    void method() {}
}
