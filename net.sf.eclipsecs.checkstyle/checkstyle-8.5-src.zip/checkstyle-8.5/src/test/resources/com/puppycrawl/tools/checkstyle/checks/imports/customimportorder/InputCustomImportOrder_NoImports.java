package com.puppycrawl.tools.checkstyle.checks.imports.customimportorder;


public class InputCustomImportOrder_NoImports {
}
