package com.puppycrawl.tools.checkstyle.utils.blockcommentposition;

/**
 * I'm a javadoc
 */
public interface InputBlockCommentPositionOnInterface {
}

/**
 * I'm a javadoc
 */
interface InputBlockCommentPositionOnInterface1 {
}

/**
 * I'm a javadoc
 */
@Deprecated
interface InputBlockCommentPositionOnInterface2 {
}
