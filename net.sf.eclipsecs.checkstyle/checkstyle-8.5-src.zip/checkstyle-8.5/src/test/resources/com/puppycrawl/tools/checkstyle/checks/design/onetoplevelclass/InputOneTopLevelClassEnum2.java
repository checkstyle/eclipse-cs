package com.puppycrawl.tools.checkstyle.checks.design.onetoplevelclass;

enum InputOneTopLevelClassEnum2inner1 {
    VALUE1, VALUE2;
}

public enum InputOneTopLevelClassEnum2 {
    VALUE1, VALUE2;
}

enum InputOneTopLevelClassEnum2inner2 {
    VALUE1, VALUE2;
}
