package com.puppycrawl.tools.checkstyle.main;

/**javadoc*/
class InputMainAstTreeStringPrinterJavadoc {
    /*not javadoc*/
    void m(){}
}
