package com.puppycrawl.tools.checkstyle.checks.javadoc.javapackage.bothfiles;

class InputJavadocPackageBothIgnored
{
}
