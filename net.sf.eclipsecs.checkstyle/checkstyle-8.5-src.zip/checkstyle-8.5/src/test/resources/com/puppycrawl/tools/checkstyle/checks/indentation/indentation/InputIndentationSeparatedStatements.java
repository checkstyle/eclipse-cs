package com.puppycrawl.tools.checkstyle.checks.indentation.indentation;//indent:0 exp:0

import java.io.*//indent:0 exp:0

    ;//indent:4 exp:4

import java.util.*//indent:0 exp:0
    //indent:4 exp:4
    ;//indent:4 exp:4

public class InputIndentationSeparatedStatements {//indent:0 exp:0
}//indent:0 exp:0
