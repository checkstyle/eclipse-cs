package com.puppycrawl.tools.checkstyle.checks.header.regexpheader;

import java.awt.*;
import java.awt.*;
import java.awt.*;
import java.awt.*;
