package com.puppycrawl.tools.checkstyle.checks.modifier.modifierorder;

public @InterfaceAnnotation @interface InputModifierOrderAnnotationDeclaration {
    int getValue();
}

@interface InterfaceAnnotation {}
