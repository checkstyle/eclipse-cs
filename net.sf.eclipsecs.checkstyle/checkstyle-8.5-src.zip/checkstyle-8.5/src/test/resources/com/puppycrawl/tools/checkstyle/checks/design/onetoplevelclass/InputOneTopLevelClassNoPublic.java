package com.puppycrawl.tools.checkstyle.checks.design.onetoplevelclass;

class InputOneTopLevelClassNoPublic
{

}

class InputOneTopLevelClassNoPublic2
{

}
