package com.puppycrawl.tools.checkstyle.checks.header.header;

import java.awt.*;

/**
 * Some doc.
 */

public class InputHeaderRegexp
{
}
