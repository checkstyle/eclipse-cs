/*OK: for test allowing to place annotation before PACKAGE_DEF.*/
@Deprecated
package com.puppycrawl.tools.checkstyle.checks.whitespace.emptylineseparator.packageinfo.test1;

import java.lang.Deprecated;
