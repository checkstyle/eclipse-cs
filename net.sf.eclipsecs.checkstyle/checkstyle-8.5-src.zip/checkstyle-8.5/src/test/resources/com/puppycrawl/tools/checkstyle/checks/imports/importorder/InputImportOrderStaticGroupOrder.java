package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import static java.lang.Math.abs;
import static org.antlr.v4.runtime.Recognizer.EOF;

import org.*;

import java.util.Set;

public class InputImportOrderStaticGroupOrder
{

}
