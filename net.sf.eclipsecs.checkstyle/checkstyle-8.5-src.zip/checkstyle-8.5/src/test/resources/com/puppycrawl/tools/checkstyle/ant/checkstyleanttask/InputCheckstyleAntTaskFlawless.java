package com.puppycrawl.tools.checkstyle.ant.checkstyleanttask;

public final class InputCheckstyleAntTaskFlawless {
    private String foo = "A short line";
}
