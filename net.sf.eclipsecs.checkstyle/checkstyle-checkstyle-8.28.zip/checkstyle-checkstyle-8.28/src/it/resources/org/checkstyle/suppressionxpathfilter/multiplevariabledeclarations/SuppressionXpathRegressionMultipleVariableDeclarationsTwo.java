package org.checkstyle.suppressionxpathfilter.multiplevariabledeclarations;

public class SuppressionXpathRegressionMultipleVariableDeclarationsTwo {
    int i1; int j1; //warn
}
