package org.checkstyle.suppressionxpathfilter.whitespacearound;

public class SuppressionXpathRegressionWhitespaceAroundNotPreceded {
    int bad= 0; //warn
    int good = 0;
}
