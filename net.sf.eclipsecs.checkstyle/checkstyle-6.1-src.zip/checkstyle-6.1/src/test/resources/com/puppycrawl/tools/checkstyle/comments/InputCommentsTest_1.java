public class /*
    i'mcomment567
    */
InputCommentsTest
{ // comment to left curly brace
}
