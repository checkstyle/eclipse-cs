package com.google.checkstyle.test.chapter7javadoc.rule711generalform;

public class InputSingleLineJavadocCheckError {
    /** {@customTag} */ //warn
    void bar() {}
}
