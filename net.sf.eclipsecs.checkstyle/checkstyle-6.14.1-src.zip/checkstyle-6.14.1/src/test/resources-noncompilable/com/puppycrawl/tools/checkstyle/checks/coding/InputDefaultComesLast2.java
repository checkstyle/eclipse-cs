//Compilable with Java8
package com.puppycrawl.tools.checkstyle.checks.coding;
public interface JsonTranslator {

    String toJson(Response one, Response two, Response three);

    String toJson(Document document);

    default String toJson(Response one) {
      return toJson(one, one, one);
    }

    default String toJson(Response one, Response two) {
      return toJson(one, one, two);
    }
  }