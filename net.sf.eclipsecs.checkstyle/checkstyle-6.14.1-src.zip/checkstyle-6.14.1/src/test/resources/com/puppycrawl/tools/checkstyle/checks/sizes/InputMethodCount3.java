package com.puppycrawl.tools.checkstyle.checks.sizes;

public class InputMethodCount3 {

    /**
     * Dummy inner class to check that the inner-classes methods are not counted for the outer class.
     */
    /**
     * Dummy method doing nothing
     */
    void doNothing50() {
    }

    /**
     * Dummy method doing nothing
     */
    void doNothing51() {
    }

    /**
     * Dummy method doing nothing
     */
    void doNothing52() {
    }

    /**
     * Dummy method doing nothing
     */
    void doNothing53() {
    }

    /**
     * Dummy method doing nothing
     */
    void doNothing54() {
    }

}