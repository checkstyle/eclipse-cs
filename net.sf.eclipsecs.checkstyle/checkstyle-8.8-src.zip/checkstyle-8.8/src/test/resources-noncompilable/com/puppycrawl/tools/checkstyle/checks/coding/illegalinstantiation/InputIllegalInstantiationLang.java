package java.lang;

class Input {
    Boolean obj = new Boolean();
    Integer obj2 = new Integer();
}

class Boolean{}
class Integer{}

class Input2 {
	String a = new String();
}
