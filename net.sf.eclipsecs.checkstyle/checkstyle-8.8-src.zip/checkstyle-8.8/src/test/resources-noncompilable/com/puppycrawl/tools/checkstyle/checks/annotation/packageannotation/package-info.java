@Deprecated
package com.puppycrawl.tools.checkstyle.checks.annotation.packageannotation;

