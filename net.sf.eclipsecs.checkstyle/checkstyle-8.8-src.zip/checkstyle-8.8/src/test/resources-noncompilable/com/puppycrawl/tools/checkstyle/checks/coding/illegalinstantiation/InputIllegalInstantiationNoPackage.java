//no package
class InputIllegalInstantiationNoPackage {
    Boolean obj1 = new Boolean(true);
    String obj2 = new String();
}
