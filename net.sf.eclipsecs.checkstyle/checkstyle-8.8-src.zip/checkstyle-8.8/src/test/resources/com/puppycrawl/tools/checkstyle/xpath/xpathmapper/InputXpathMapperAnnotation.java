package com.puppycrawl.tools.checkstyle.xpath.xpathmapper;

@SuppressWarnings("test")
public class InputXpathMapperAnnotation {

}
