package com.puppycrawl.tools.checkstyle.checks.naming.abstractclassname;

public class InputAbstractClassNameFormerFalsePositive
{
    class Abstract {
        
    }
    
    class AbstractClass {
        
    }
}
