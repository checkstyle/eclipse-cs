// someexamples of 1.5 extensions
package com.puppycrawl.tools.checkstyle.checks.outertypefilename;

public class InputOuterTypeFilename2 {
    
  
}
