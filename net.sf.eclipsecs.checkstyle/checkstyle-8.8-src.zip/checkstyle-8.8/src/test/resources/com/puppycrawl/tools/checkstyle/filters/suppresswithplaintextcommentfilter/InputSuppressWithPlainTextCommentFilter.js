// CS-OFF
alert( 2 === 1 );

// CS-ON
alert( 2 === 1 );

alert( 2 != 1 );
