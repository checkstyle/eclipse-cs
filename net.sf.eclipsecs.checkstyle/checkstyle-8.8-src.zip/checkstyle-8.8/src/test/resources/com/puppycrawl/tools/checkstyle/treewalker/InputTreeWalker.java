package com.puppycrawl.tools.checkstyle.treewalker;
/*comment*/
public class InputTreeWalker {
}
class InputTreeWalkerInner {
}
