package com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity.inputs.b;

public class BClass {
}
