package com.puppycrawl.tools.checkstyle.javaparser;

/**
 * Some Javadoc.
 *
 * <p>{@code function} will never be invoked with a null value.
 *
 * @since 8.0
 */
public class InputJavaParserHiddenComments {

}
// inline comment
