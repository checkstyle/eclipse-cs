package com.puppycrawl.tools.checkstyle.ant.checkstyleanttask;

public final class InputCheckstyleAntTaskWarning {
    int foo;
    int foo1;
}
