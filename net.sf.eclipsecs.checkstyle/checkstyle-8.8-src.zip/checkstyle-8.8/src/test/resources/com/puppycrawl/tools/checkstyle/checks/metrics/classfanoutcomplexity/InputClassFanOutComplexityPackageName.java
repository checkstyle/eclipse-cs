package com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity;

public interface InputClassFanOutComplexityPackageName {
    public com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity.InputClassFanOutComplexityPackageName method1();

    public com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity.InputClassFanOutComplexityPackageName method2();
}
