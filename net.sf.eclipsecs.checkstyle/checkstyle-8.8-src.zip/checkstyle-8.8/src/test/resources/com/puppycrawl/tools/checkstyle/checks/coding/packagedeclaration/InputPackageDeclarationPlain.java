package com.puppycrawl.tools.checkstyle.checks.coding.packagedeclaration;

class InputPackageDeclarationPlain {
    public String value;
    
    private void get(){
    }
}
