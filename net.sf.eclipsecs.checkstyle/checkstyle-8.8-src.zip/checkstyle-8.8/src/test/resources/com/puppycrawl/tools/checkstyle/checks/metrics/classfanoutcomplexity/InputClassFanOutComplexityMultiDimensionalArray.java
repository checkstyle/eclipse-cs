package com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity;

public class InputClassFanOutComplexityMultiDimensionalArray {
    public Object[][] get() {
        return new Object[][]{};
    }
}
