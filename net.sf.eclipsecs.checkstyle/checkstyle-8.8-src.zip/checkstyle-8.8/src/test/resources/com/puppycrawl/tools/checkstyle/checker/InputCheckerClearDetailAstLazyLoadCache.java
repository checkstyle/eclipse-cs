package com.puppycrawl.tools.checkstyle.checker;

public class InputCheckerClearDetailAstLazyLoadCache {

    public
    /*
     * Javadoc comment
     */
    static void foo() {
        return;
    }
}
