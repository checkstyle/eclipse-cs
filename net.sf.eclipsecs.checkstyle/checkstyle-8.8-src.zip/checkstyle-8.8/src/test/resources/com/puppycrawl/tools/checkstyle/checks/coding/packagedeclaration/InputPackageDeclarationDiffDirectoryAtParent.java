package com.puppycrawl.tools.checkstyle.checks.coding;

public class InputPackageDeclarationDiffDirectoryAtParent {
    public String value;

    private void get(){
    }
}
