package org.checkstyle.suppressionxpathfilter.cyclomaticcomplexity;

public class SuppressionXpathRegressionCyclomaticOne {
    public void test(int a, int b) { //warn
        if (a > b) {

        } else {

        }
    }
}
