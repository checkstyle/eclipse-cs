package com.puppycrawl.tools.checkstyle.imports;

import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

public class InputCustomImportOrderNoValid {
}
