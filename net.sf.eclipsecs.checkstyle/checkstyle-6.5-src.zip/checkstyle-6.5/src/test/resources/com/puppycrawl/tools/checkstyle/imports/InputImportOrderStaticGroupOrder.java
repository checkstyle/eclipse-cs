package com.puppycrawl.tools.checkstyle.imports;

import static java.lang.Math.abs;
import static org.abego.treelayout.Configuration.AlignmentInLevel;

import org.*;

import java.util.Set;

public class InputImportOrderStaticGroupOrder
{

}
