package com.puppycrawl.tools.checkstyle;

public class LocalAnnotations
{
    public @interface Rule {
        
    }
}
