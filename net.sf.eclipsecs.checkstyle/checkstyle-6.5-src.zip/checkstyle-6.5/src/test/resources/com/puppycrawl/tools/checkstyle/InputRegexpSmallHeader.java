package com.puppycrawl.tools.checkstyle;


/**
 */
public class InputRegexpSmallHeader {}
