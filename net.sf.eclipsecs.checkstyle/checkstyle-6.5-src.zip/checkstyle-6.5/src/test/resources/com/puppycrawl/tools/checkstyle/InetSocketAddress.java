package com.puppycrawl.tools.checkstyle;

public class InetSocketAddress
{
    class Arrays {
        
    }
}
