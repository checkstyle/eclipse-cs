package com.puppycrawl.tools.checkstyle.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

public class AnnotationsUseStyleParams
{
    @Target({})
    public @interface myAnn {
        
    }
}
