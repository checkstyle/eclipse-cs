package com.puppycrawl.tools.checkstyle.comments;
// my class
class InputCommentsTest_2
{
    /**
     * Lines <b>method</b>.
     * 
     * @return string.
     */
    protected String line()
    {
		return null;
    }
}
