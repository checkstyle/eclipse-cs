package com.puppycrawl.tools.checkstyle.checks;

public class InputSuppressWarningsHolder3 {

    @SuppressWarnings()
    int a;
    private @interface SuppressWarnings {
    }
}
