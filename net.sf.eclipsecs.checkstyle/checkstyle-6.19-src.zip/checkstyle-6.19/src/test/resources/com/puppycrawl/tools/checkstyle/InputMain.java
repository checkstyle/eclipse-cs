package com.puppycrawl.tools.checkstyle;
/*comment*/
public class InputMain {
}
class InputMainInner {
}
