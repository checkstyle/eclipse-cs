// someexamples of 1.5 extensions
package com.puppycrawl.tools.checkstyle.checks;

public class InputOuterTypeFilename2 {
    
  
}
