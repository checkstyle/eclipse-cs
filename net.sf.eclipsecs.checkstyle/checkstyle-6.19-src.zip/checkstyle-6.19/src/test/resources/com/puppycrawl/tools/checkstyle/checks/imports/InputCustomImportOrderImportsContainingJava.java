package com.puppycrawl.tools.checkstyle.checks.imports;

import java.io.File;
import javax.lang.model.SourceVersion;
import com.puppycrawl.tools.checkstyle.checks.javadoc.AbstractJavadocCheck;

public class InputCustomImportOrderImportsContainingJava {}
