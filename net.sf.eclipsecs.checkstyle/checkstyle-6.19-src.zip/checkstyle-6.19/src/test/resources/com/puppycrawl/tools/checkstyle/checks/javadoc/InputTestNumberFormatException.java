package com.puppycrawl.tools.checkstyle.checks.javadoc;

/** <ul><li>a' {@link EntityEntry} (by way of {@link #;}</li></ul> */
class InputTestNumberFormatException{}