package com.puppycrawl.tools.checkstyle.ant;

public final class InputCheckstyleAntTaskWarning {
    int foo;
    int foo1;
}
