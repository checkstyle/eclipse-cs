package com.nameofcompany.nameofdivision.nameofproject.systemtests.parallel.areaoftest.featuretested.flowtested;

public class InputLongPackageStatement {
    @Override
    public String toString() {
        return "This is very long line that should be logged because it is not package";
    }
}
